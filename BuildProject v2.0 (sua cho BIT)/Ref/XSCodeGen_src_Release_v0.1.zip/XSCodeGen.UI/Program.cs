#region Copyright (C) 2006 Feng Liu
/*****************************************************************************
Copyright (C) 2006 Feng Liu

This class is used by XSCodeGen, a freeware initialized by Feng Liu. 
The intention of the XSCodeGen is to automatically generate classes and 
stored procedures basing on schema of tables in database by leveraging common
implementation pattern and practices.

Feel free to distribute and modify XSCodeGen to adopt your need. Please send feedback 
or your improvement back to Feng Liu, at waterman1997@hotmail.com. So other can benefit from 
these improvement and suggestions.

This XSCodeGen is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*****************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.Windows.Forms;

using System.Diagnostics;

using Microsoft.SqlServer.Management;
using Microsoft.SqlServer.Management.Smo;

namespace XSCodeGen.UI
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args != null && args.Length > 2)
            {
                Trace.WriteLine(String.Format("Run XSCodeGen from commandline.", System.DateTime.Now.ToString("s")));
                Trace.Indent();
                foreach (string s in args)
                {
                    Trace.WriteLine(s);
                }
                Trace.Unindent();
                Trace.WriteLine(System.Environment.NewLine);


                string server = null, database = null, tables = null, sTableType = "0", outputPath = null, spprefix = "pr_", codeNameSpace = "", sXsltFolders = null, sXsltTypes = null, sOutputFileTypes = null;
                string[] tableNames = null, xsltFolders = null, xsltTypes = null, outputFileTypes = null;
                bool keepSymbol = false;

                foreach (string s in args)
                {
                    if (s.StartsWith("/s:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        server = s.Remove(0, 3).Trim();
                    }
                    else if (s.StartsWith("/d:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        database = s.Remove(0, 3).Trim();
                    }
                    else if (s.StartsWith("/t:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        tables = s.Remove(0, 3).Trim();
                        tableNames = tables.Split(',');
                    }
                    else if (s.StartsWith("/o:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        outputPath = s.Remove(0, 3).Trim();
                    }
                    else if (s.StartsWith("/n:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        codeNameSpace = s.Remove(0, 3).Trim();
                    }
                    else if (s.StartsWith("/sp:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        spprefix = s.Remove(0, 4).Trim();
                    }
                    else if (s.StartsWith("/xsltfolders:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        sXsltFolders = s.Remove(0, 13).Trim();
                        xsltFolders = sXsltFolders.Split(',');
                    }
                    else if (s.StartsWith("/xslttypes:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        sXsltTypes = s.Remove(0, 11).Trim();
                        xsltTypes = sXsltTypes.Split(',');
                    }
                    else if (s.StartsWith("/outputfiletypes:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        sOutputFileTypes = s.Remove(0, 17).Trim();
                        outputFileTypes = sOutputFileTypes.Split(',');
                    }
                    else if (s.StartsWith("/tabletype:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        sTableType = s.Remove(0, 11).Trim();
                    }
                    else if (s.StartsWith("/keepsymbol", StringComparison.InvariantCultureIgnoreCase))
                    {
                        keepSymbol = true;
                    }
                }

                if (string.IsNullOrEmpty(outputPath))
                {
                    outputPath = System.IO.Path.Combine(System.Environment.CurrentDirectory, "XSCodeGenOutput");
                }

                if (!String.IsNullOrEmpty(server)
                    && !String.IsNullOrEmpty(database)
                    && tableNames != null && tableNames.Length > 0)
                {
                    XSCodeGen.Library.TableType tableType = XSCodeGen.Library.TableType.Normal;
                    if (sTableType.Equals("1"))
                    {
                        tableType = XSCodeGen.Library.TableType.Lookup;
                    }

                    Trace.WriteLine("Call CodeGenerator.GenerateOutput.");
                    XSCodeGen.Library.CodeGenerator.GenerateOutput(server, 
                        database, 
                        tableNames, 
                        tableType,
                        xsltFolders,
                        XSCodeGen.Library.Utility.ConvertToXsltOutputType(xsltTypes),
                        outputPath, 
                        outputFileTypes,
                        codeNameSpace, 
                        spprefix, 
                        keepSymbol, 
                        false);
                }

                return;
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmMain());
            }
        }

    }
}