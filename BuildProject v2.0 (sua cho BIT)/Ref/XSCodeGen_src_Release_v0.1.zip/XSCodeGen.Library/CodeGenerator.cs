#region Copyright (C) 2006 Feng Liu
/*****************************************************************************
Copyright (C) 2006 Feng Liu

This class is used by XSCodeGen, a freeware initialized by Feng Liu. 
The intention of the XSCodeGen is to automatically generate classes and 
stored procedures basing on schema of tables in database by leveraging common
implementation pattern and practices.

Feel free to distribute and modify XSCodeGen to adopt your need. Please send feedback 
or your improvement back to Feng Liu, at waterman1997@hotmail.com. So other can benefit from 
these improvement and suggestions.

This XSCodeGen is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*****************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

using Microsoft.SqlServer.Management;
using Microsoft.SqlServer.Management.Smo;

namespace XSCodeGen.Library
{
    /// <summary>
    /// TableType defines the type of table could be processed by XSCodeGen library.
    /// </summary>
    public enum TableType
    {
        /// <summary>
        /// Normal tables
        /// </summary>
        Normal = 0,
        /// <summary>
        /// Lookup tables
        /// </summary>
        Lookup = 1
    }

    /// <summary>
    /// XsltOutputType defines the type of xslt output could be processed by XSCodeGen library.
    /// </summary>
    public enum XsltOutputType
    {
        /// <summary>
        /// Individual means each table and xslt combination will have its own output file.
        /// </summary>
        Individual = 0,
        /// <summary>
        /// Single means XSCodeGen will cache output result, and generate one single file for all combination of tables and xslt files.
        /// </summary>
        Combination = 1
    }

    /// <summary>
    /// CodeGenerator is a static class the called by either commanline application or windows form application to generate code
    /// </summary>
    public static class CodeGenerator
    {
         /// <summary>
        /// GenerateOutput generate xml files from Server, Database, TableNames,
        /// then it calls GenerateCode to generate code files basing on xslt files.
        /// </summary>
        /// <param name="serverName">SQL Server name. </param>
        /// <param name="databaseName">Database name. </param>
        /// <param name="tableNames">Table name array. </param>
        /// <param name="tableType">Table type to be processed in code generation process: 0-Normal, 1-lookup tables. </param>
        /// <param name="xsltFolders">xslt folder array. </param>
        /// <param name="xsltOutputTypes">xslt output types array, corresponding to xsltFolders. </param>
        /// <param name="outputPath">the root directory of generation output. </param>
        /// <param name="outputFileTypes">Output file type array. </param>
        /// <param name="codeNameSpace">namespace of the code going to be generated. </param>
        /// <param name="spprefix">stored procedure naimg prefix. </param>
        /// <param name="keepSymbol">a boolean value indicates whether keep the symbol in the table names and column names. </param>
        public static void GenerateOutput(string serverName, 
            string databaseName, 
            string[] tableNames, 
            TableType tableType,
            string[] xsltFolders,
            XsltOutputType[] xsltOutputTypes,
            string outputPath,
            string[] outputFileTypes,
            string codeNameSpace, 
            string spprefix, 
            bool keepSymbol)
        {
            GenerateOutput(serverName, 
                databaseName, 
                tableNames, 
                tableType, 
                xsltFolders,
                xsltOutputTypes,
                outputPath,
                outputFileTypes,
                codeNameSpace, 
                spprefix, 
                keepSymbol, 
                false);
        }

        /// <summary>
        /// GenerateOutput generate xml files from Server, Database, TableNames,
        /// then it calls GenerateCode to generate code files basing on xslt files.
        /// </summary>
        /// <param name="serverName">SQL Server name. </param>
        /// <param name="databaseName">Database name. </param>
        /// <param name="tableNames">Table name array. </param>
        /// <param name="tableType">Table type to be processed in code generation process: 0-Normal, 1-lookup tables. </param>
        /// <param name="xsltFolders">xslt folder array. </param>
        /// <param name="xsltOutputTypes">xslt output types array, corresponding to xsltFolders. </param>
        /// <param name="outputPath">the root directory of generation output. </param>
        /// <param name="outputFileTypes">Output file type array. </param>
        /// <param name="codeNameSpace">namespace of the code going to be generated. </param>
        /// <param name="spprefix">stored procedure naimg prefix. </param>
        /// <param name="keepSymbol">a boolean value indicates whether keep the symbol in the table names and column names. </param>
        /// <param name="interactive">a boolean value indicates whether the caller is from an interactive form, the defaut is false (command line mode). </param>
        public static void GenerateOutput(string serverName,
            string databaseName,
            string[] tableNames,
            TableType tableType,
            string[] xsltFolders,
            XsltOutputType[] xsltOutputTypes,
            string outputPath,
            string[] outputFileTypes,
            string codeNameSpace,
            string spprefix,
            bool keepSymbol,
            bool interactive)
        {
            Trace.WriteLine(String.Format("GenerateOutput is called at {0}.", System.DateTime.Now.ToString("s")));

            //check the parameter validation
            if (tableNames != null && tableNames.Length > 0
                && !String.IsNullOrEmpty(serverName)
                && !String.IsNullOrEmpty(databaseName)
                && !String.IsNullOrEmpty(codeNameSpace)
                && !String.IsNullOrEmpty(spprefix)
                )
            {
                //create instance of SQL server
                Trace.WriteLine(String.Format("Creating SQL Server Instance of {0}", serverName));
                Server server = new Server(serverName);
                if (server == null)
                {
                    if (interactive)
                        throw new ApplicationException(String.Format("Server {0} not found.", serverName));
                    else
                    {
                        Trace.TraceError(String.Format("Server {0} not found.", serverName));
                        return;
                    }
                }

                //create instance of Database
                Trace.WriteLine(String.Format("Creating Database Instance of {0}", databaseName));
                Database database = server.Databases[databaseName];
                if (database == null)
                {
                    if (interactive)
                        throw new ApplicationException(String.Format("Database {0} not found.", databaseName));
                    else
                    {
                        Trace.TraceError(String.Format("Database {0} not found.", databaseName));
                        return;
                    }
                }

                Trace.WriteLine("clean and create output folders.");

                //get output path from parameter OR appSettings, 
                if (String.IsNullOrEmpty(outputPath))
                    outputPath = Utility.GetAppSetting("XSCodeGen.Library.CodeGenerator.OutputFolder", System.Environment.CurrentDirectory);

                //clean xml output folder
                string xmlFolder = System.IO.Path.Combine(outputPath, "xml");
                if (System.IO.Directory.Exists(xmlFolder))
                {
                    System.IO.Directory.Delete(xmlFolder, true);
                }
                System.IO.Directory.CreateDirectory(xmlFolder);

                Trace.WriteLine("Starting generation of xml files");

                //check the *.*
                if (tableNames.Length == 1 && tableNames[0] != null && tableNames[0].Contains("*"))
                {
                    if (tableNames[0].Equals("*"))
                    {
                        foreach (Table table in database.Tables)
                        {
                            Trace.WriteLine(String.Format("Generating xml for Table {0}.", table.Name));
                            SmoHelper.GenerateEntityXmlFromTable(table, keepSymbol, xmlFolder, spprefix, codeNameSpace, tableType);
                        }
                    }
                    else if (tableNames[0].EndsWith(".*"))
                    {
                        string schema = tableNames[0].Replace(".*", "");
                        foreach (Table table in database.Tables)
                        {
                            if (table.Schema.Equals(schema, StringComparison.InvariantCultureIgnoreCase))
                            {
                                Trace.WriteLine(String.Format("Generating xml for Table {0}.", table.Name));
                                SmoHelper.GenerateEntityXmlFromTable(table, keepSymbol, xmlFolder, spprefix, codeNameSpace, tableType);
                            }
                        }

                    }
                }
                else
                {
                    //foreach table, generate xml
                    foreach (string tableNameItem in tableNames)
                    {
                        string tableName = tableNameItem.Trim();
                        Table table = database.Tables[tableName];
                        if (table == null)
                        {
                            if (tableName.IndexOf('.') > 0)
                            {
                                string schema = tableName.Substring(0, tableName.IndexOf('.'));
                                string tname = tableName.Substring(tableName.IndexOf('.') + 1);
                                table = database.Tables[tname, schema];
                            }
                        }

                        if (table != null)
                        {
                            Trace.WriteLine(String.Format("Generating xml for Table {0}.", tableName));
                            SmoHelper.GenerateEntityXmlFromTable(table, keepSymbol, xmlFolder, spprefix, codeNameSpace, tableType);
                        }
                        else
                        {
                            Trace.WriteLine(String.Format("Table {0} not found.", tableName));
                        }
                    }
                }
                Trace.WriteLine("End generation of xml files");

                if (xsltFolders != null && xsltFolders.Length > 0
                    && xsltOutputTypes != null && xsltOutputTypes.Length > 0
                    && outputFileTypes != null && outputFileTypes.Length > 0
                    && xsltFolders.Length == xsltOutputTypes.Length
                    && xsltFolders.Length == outputFileTypes.Length)
                {
                    foreach (string outputFileType in outputFileTypes)
                    {
                        //clean c sharp output folder
                        string outputSubfolderPath = System.IO.Path.Combine(outputPath, outputFileType.Trim());
                        if (System.IO.Directory.Exists(outputSubfolderPath))
                        {
                            System.IO.Directory.Delete(outputSubfolderPath, true);
                        }
                        System.IO.Directory.CreateDirectory(outputSubfolderPath);
                    }

                    Trace.WriteLine("Starting generation of output files");
                    for (int i = 0; i < xsltFolders.Length; i++)
                    {
                        string xsltFolderPath = xsltFolders[i].Trim();
                        string outputSubfolderPath = System.IO.Path.Combine(outputPath, outputFileTypes[i].Trim());
                        Trace.WriteLine(String.Format("Generating {2} output with xslt in {0}, to {1}.", xsltFolderPath, outputSubfolderPath, outputFileTypes[i].Trim()));
                        GenerateCode(xmlFolder, xsltFolderPath, outputSubfolderPath, outputFileTypes[i].Trim(), xsltOutputTypes[i]);
                    }
                    Trace.WriteLine("End generation of output files");
                }

            }
            else
            {
                Trace.TraceError("GenerateOutput is called with invalid parameters.");
            }
        }

        /// <summary>
        /// GenerateCode generate output file(s) using xml files and xslt files.
        /// </summary>
        /// <param name="xmlFolder">folder contains xml files. </param>
        /// <param name="xsltFolderPath">folder contains xsl(t) files. </param>
        /// <param name="outputSubfolderPath">output file path. </param>
        /// <param name="outputFileType">type of output files, such as cs, vb, sql, etc. </param>
        /// <param name="xsltOutputType">xslt output type, Individual or Combination. </param>
        public static void GenerateCode(string xmlFolder, string xsltFolderPath, string outputSubfolderPath, string outputFileType, XsltOutputType xsltOutputType)
        {
            if (!String.IsNullOrEmpty(xmlFolder) && !String.IsNullOrEmpty(xsltFolderPath)
                && !String.IsNullOrEmpty(outputSubfolderPath) && !String.IsNullOrEmpty(outputFileType))
            {
                if (System.IO.Directory.Exists(xmlFolder) && System.IO.Directory.Exists(xsltFolderPath))
                {
                    if (!System.IO.Directory.Exists(outputSubfolderPath))
                    {
                        System.IO.Directory.CreateDirectory(outputSubfolderPath);
                    }

                    string[] filePaths = System.IO.Directory.GetFiles(xmlFolder, "*.xml");
                    string[] xsltFilePaths = System.IO.Directory.GetFiles(xsltFolderPath, "*.xsl*");

                    if (xsltOutputType == XsltOutputType.Combination)
                    {
                        StringBuilder sb = new StringBuilder();
                        string outputFilePath = System.IO.Path.Combine(outputSubfolderPath, String.Format("XSCodeGenOutput_Output_{0}.{1}", Utility.GetDigitLetter(System.DateTime.Now.ToString("s")), outputFileType));
                        sb.Append(String.Format("-- XSCodeGen Generated code"));
                        sb.Append(System.Environment.NewLine);

                        Trace.WriteLine("Generating combination outputs.");
                        GenerateCode(filePaths, xsltFilePaths, sb);

                        using (System.IO.StreamWriter sw = new System.IO.StreamWriter(outputFilePath, false, Encoding.UTF8))
                        {
                            sw.Write(sb.ToString());
                            sw.Flush();
                            sw.Close();
                        }
                    }
                    else
                    {
                        Trace.WriteLine("Generating individual outputs.");
                        GenerateCode(filePaths, xsltFilePaths, outputSubfolderPath, outputFileType);
                    }
                }
            }
        }

        /// <summary>
        /// GenerateFile generate all combination of xml files and xslt files, concatenate then together, save into the output file.
        /// </summary>
        /// <param name="xmlFolder">folder has xml files. </param>
        /// <param name="xsltFolder">folder has xslt files. </param>
        /// <param name="outputFilePath">output file path. </param>
        public static void GenerateFile(string xmlFolder, string xsltFolder, string outputFilePath)
        {
            GenerateFile(xmlFolder, xsltFolder, outputFilePath, null, null);
        }

        /// <summary>
        /// GenerateFile generate all combination of xml files and xslt files, concatenate then together, save into the output file.
        /// </summary>
        /// <param name="xmlFolder">folder has xml files.</param>
        /// <param name="xsltFolder">folder has xslt files.</param>
        /// <param name="outputFilePath">output file path.</param>
        /// <param name="containerFilePath">The container file path.</param>
        /// <param name="placeHolderToReplace">The place holder to replace.</param>
        public static void GenerateFile(string xmlFolder, string xsltFolder, string outputFilePath, string containerFilePath, string placeHolderToReplace)
        {
            if (!String.IsNullOrEmpty(xmlFolder) && !String.IsNullOrEmpty(xsltFolder))
            {
                if (System.IO.Directory.Exists(xmlFolder) && System.IO.Directory.Exists(xsltFolder))
                {

                    string[] filePaths = System.IO.Directory.GetFiles(xmlFolder, "*.xml");
                    string[] xsltFilePaths = System.IO.Directory.GetFiles(xsltFolder, "*.xsl*");

                    if (filePaths != null && filePaths.Length > 0 && xsltFilePaths != null && xsltFilePaths.Length > 0)
                    {
                        StringBuilder sb = new StringBuilder();
                        XSCodeGen.Library.CodeGenerator.GenerateCode(filePaths, xsltFilePaths, sb, false, true);

                        if (!String.IsNullOrEmpty(containerFilePath) 
                            && !String.IsNullOrEmpty(placeHolderToReplace)
                            && System.IO.File.Exists(containerFilePath))
                        {
                            System.Text.Encoding outputEncoding = Encoding.UTF8;
                            string containerText = null;
                            using (System.IO.StreamReader sr = new System.IO.StreamReader(containerFilePath, true))
                            {
                                containerText = sr.ReadToEnd();
                                outputEncoding = sr.CurrentEncoding;
                                sr.Close();
                            }

                            if (!String.IsNullOrEmpty(containerText))
                            {
                                containerText = containerText.Replace(placeHolderToReplace, sb.ToString());
                            }
                            else
                            {
                                containerText = sb.ToString();
                            }

                            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(outputFilePath, false, outputEncoding))
                            {
                                sw.Write(containerText);
                                sw.Flush();
                                sw.Close();
                            }
                        }
                        else
                        {
                            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(outputFilePath, false, Encoding.UTF8))
                            {
                                sw.Write(sb.ToString());
                                sw.Flush();
                                sw.Close();
                            }
                        }
                    }

                }
            }
        }

        /// <summary>
        /// GenerateCode uses files and xslt files to generate output files.
        /// </summary>
        /// <param name="filePaths">xml files. </param>
        /// <param name="xsltFilePaths">xslt files. </param>
        /// <param name="outputSubfolderPath">output folder. </param>
        /// <param name="outputFileType">output file type, such as cs, vb, sql etc. </param>
        private static void GenerateCode(string[] filePaths, string[] xsltFilePaths, string outputSubfolderPath, string outputFileType)
        {

            if (filePaths != null && filePaths.Length > 0 && xsltFilePaths != null && xsltFilePaths.Length > 0)
            {
                foreach (string filePath in filePaths)
                {
                    for (int i = 0; i < xsltFilePaths.Length; i++)
                    {
                        if (System.IO.File.Exists(xsltFilePaths[i]))
                        {
                            string outputFilePath;
                            string xsltFileName = System.IO.Path.GetFileNameWithoutExtension(xsltFilePaths[i]);
                            int idxSuffix = xsltFileName.IndexOf("2");
                            if (idxSuffix > 0 && idxSuffix < xsltFileName.Length - 1)
                            {
                                string suffix = xsltFileName.Remove(0, idxSuffix + 1);
                                if (suffix.Equals("class", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    outputFilePath = String.Concat(System.IO.Path.Combine(outputSubfolderPath, System.IO.Path.GetFileNameWithoutExtension(filePath)), ".", outputFileType);
                                }
                                else
                                {
                                    string csSubfolder = System.IO.Path.Combine(outputSubfolderPath, suffix);
                                    if (!System.IO.Directory.Exists(csSubfolder))
                                    {
                                        System.IO.Directory.CreateDirectory(csSubfolder);
                                    }
                                    outputFilePath = String.Concat(System.IO.Path.Combine(csSubfolder, System.IO.Path.GetFileNameWithoutExtension(filePath)), suffix, ".", outputFileType);
                                }
                            }
                            else
                            {
                                outputFilePath = String.Concat(System.IO.Path.Combine(outputSubfolderPath, System.IO.Path.GetFileNameWithoutExtension(filePath)),
                                i == 0 ? "" : i.ToString(), ".", outputFileType);
                            }

                            if (System.IO.File.Exists(outputFilePath))
                            {
                                System.IO.File.Delete(outputFilePath);
                            }

                            Trace.WriteLine(String.Format("Transforming {1} with {0}, to {2}.", xsltFilePaths[i], filePath, outputFilePath));
                            Utility.Transform(xsltFilePaths[i], filePath, outputFilePath);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// GenerateCode uses files and xslt files to append transform result into StringBuilder.
        /// </summary>
        /// <param name="filePaths">xml files. </param>
        /// <param name="xsltFilePaths">xslt files. </param>
        /// <param name="sb">an instance of StringBuilder. </param>
        private static void GenerateCode(string[] filePaths, string[] xsltFilePaths, StringBuilder sb)
        {
            GenerateCode(filePaths, xsltFilePaths, sb, true, true);
        }

        /// <summary>
        /// GenerateCode uses files and xslt files to append transform result into StringBuilder.
        /// </summary>
        /// <param name="filePaths">xml files. </param>
        /// <param name="xsltFilePaths">xslt files. </param>
        /// <param name="sb">an instance of StringBuilder. </param>
        /// <param name="addComments">a boolean value indicates whether add comments between transform results. </param>
        /// <param name="addNewLine">a boolean value indicates whether add new line between transform results. </param>
        private static void GenerateCode(string[] filePaths, string[] xsltFilePaths, StringBuilder sb, bool addComments, bool addNewLine)
        {
            if (filePaths != null && filePaths.Length > 0 && xsltFilePaths != null && xsltFilePaths.Length > 0 && sb!=null)
            {
                foreach (string filePath in filePaths)
                {
                    for (int i = 0; i < xsltFilePaths.Length; i++)
                    {
                        if (addComments)
                        {
                            sb.Append(String.Format("-- XSCodeGen Generated from {0} and {1} @ {2}",
                                System.IO.Path.GetFileName(filePath),
                                System.IO.Path.GetFileName(xsltFilePaths[i]),
                                System.DateTime.Now.ToString("s")));
                            sb.Append(System.Environment.NewLine);
                        }
                        sb.Append(Utility.Transform(xsltFilePaths[i], filePath));
                        if (addNewLine)
                        {
                            sb.Append(System.Environment.NewLine);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// GenerateClass method generates entity class and service class files. 
        /// </summary>
        /// <param name="xmlFolder">the folder contains xml files. </param>
        /// <param name="csFolder">the folder will store the generated cs files. </param>
        /// <param name="csXsltFolder">the folder contains xslt/xsl files. </param>
        [Obsolete("This method has been refactored to GenerateCode, please use GenerateCode instead.")]
        public static void GenerateClass(string xmlFolder, string csFolder, string csXsltFolder)
        {
            if (!String.IsNullOrEmpty(xmlFolder) && !String.IsNullOrEmpty(csFolder) && !String.IsNullOrEmpty(csXsltFolder))
            {
                if (System.IO.Directory.Exists(xmlFolder) && System.IO.Directory.Exists(csXsltFolder))
                {
                    if (!System.IO.Directory.Exists(csFolder))
                    {
                        System.IO.Directory.CreateDirectory(csFolder);
                    }

                    string[] filePaths = System.IO.Directory.GetFiles(xmlFolder, "*.xml");
                    string[] xsltFilePaths = System.IO.Directory.GetFiles(csXsltFolder, "*.xsl*");

                    if (filePaths != null && filePaths.Length > 0 && xsltFilePaths != null && xsltFilePaths.Length>0)
                    {
                        foreach (string filePath in filePaths)
                        {
                            for (int i = 0; i < xsltFilePaths.Length; i++)
                            {
                                if (System.IO.File.Exists(xsltFilePaths[i]))
                                {
                                    string outputFilePath;
                                    string xsltFileName = System.IO.Path.GetFileNameWithoutExtension(xsltFilePaths[i]);
                                    int idxSuffix = xsltFileName.IndexOf("2");
                                    if (idxSuffix > 0 && idxSuffix < xsltFileName.Length-1)
                                    {
                                        string suffix = xsltFileName.Remove(0, idxSuffix+1);
                                        if (suffix.Equals("class", StringComparison.InvariantCultureIgnoreCase))
                                        {
                                            outputFilePath = String.Concat(System.IO.Path.Combine(csFolder, System.IO.Path.GetFileNameWithoutExtension(filePath)), ".cs");
                                        }
                                        else
                                        {
                                            string csSubfolder = System.IO.Path.Combine(csFolder, suffix);
                                            if (!System.IO.Directory.Exists(csSubfolder))
                                            {
                                                System.IO.Directory.CreateDirectory(csSubfolder);
                                            }
                                            outputFilePath = String.Concat(System.IO.Path.Combine(csSubfolder, System.IO.Path.GetFileNameWithoutExtension(filePath)), suffix, ".cs");
                                        }
                                    }
                                    else
                                    {
                                        outputFilePath = String.Concat(System.IO.Path.Combine(csFolder, System.IO.Path.GetFileNameWithoutExtension(filePath)),
                                        i == 0 ? "" : i.ToString(), ".cs");
                                    }

                                    if (System.IO.File.Exists(outputFilePath))
                                    {
                                        System.IO.File.Delete(outputFilePath);
                                    }

                                    Utility.Transform(xsltFilePaths[i], filePath, outputFilePath);
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// GenerateStoredProcedure method generates one sql script to create corresponding stored procedures. 
        /// </summary>
        /// <param name="xmlFolder">the folder contains xml file. </param>
        /// <param name="spFolder">the folder will store the generated sql file. </param>
        /// <param name="spXsltFolder">the folder contains xslt/xsl files. </param>
        [Obsolete("This method has been refactored to GenerateCode, please use GenerateCode instead.")]
        public static void GenerateStoredProcedure(string xmlFolder, string spFolder, string spXsltFolder)
        {
            if (!String.IsNullOrEmpty(xmlFolder) && !String.IsNullOrEmpty(spFolder) && !String.IsNullOrEmpty(spXsltFolder))
            {
                if (System.IO.Directory.Exists(xmlFolder) && System.IO.Directory.Exists(spXsltFolder))
                {
                    if (!System.IO.Directory.Exists(spFolder))
                    {
                        System.IO.Directory.CreateDirectory(spFolder);
                    }

                    StringBuilder sb = new StringBuilder();
                    string outputFilePath = System.IO.Path.Combine(spFolder, String.Format("XSCodeGenOutput_Output_{0}.sql", Utility.GetDigitLetter(System.DateTime.Now.ToString("s"))));
                    sb.Append(String.Format("-- XSCodeGen Generate SQL scripts"));
                    sb.Append(System.Environment.NewLine);

                    string[] filePaths = System.IO.Directory.GetFiles(xmlFolder, "*.xml");
                    string[] xsltFilePaths = System.IO.Directory.GetFiles(spXsltFolder, "*.xsl*");

                    if (filePaths != null && filePaths.Length > 0 && xsltFilePaths != null && xsltFilePaths.Length > 0)
                    {
                        foreach (string filePath in filePaths)
                        {
                            for (int i = 0; i < xsltFilePaths.Length; i++)
                            {
                                 sb.Append(String.Format("-- XSCodeGen Generated from {0} and {1} @ {2}",
                                     System.IO.Path.GetFileName(filePath),
                                     System.IO.Path.GetFileName(xsltFilePaths[i]),
                                     System.DateTime.Now.ToString("s")));
                                 sb.Append(System.Environment.NewLine);
                                 sb.Append(Utility.Transform(xsltFilePaths[i], filePath));
                                 sb.Append(System.Environment.NewLine);
                                 sb.Append(System.Environment.NewLine);
                             }
                        }
                    }


                }
            }
        }
    
    }
}