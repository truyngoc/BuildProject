using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Threading;
using System.Security.Principal;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;

namespace XSCodeGen.Library
{
    /// <summary>
    /// Utility is a static class that has common funtionality used by LazyCode other classes
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// GetAppSetting returns value of specified key defined in appSettings section of application config file. 
        /// </summary>
        /// <param name="key">key of the appSetting</param>
        /// <param name="defaultValue">the default value, used when no value defined in config file. </param>
        /// <returns>a string value read from config file. </returns>
        public static string GetAppSetting(string key, string defaultValue)
        {
            string retVal = ConfigurationManager.AppSettings[key];
            if (retVal == null)
            {
                retVal = defaultValue;
            }
            return retVal;
        }

        /// <summary>
        /// GetDigit removes characters that are not number from the input string.
        /// </summary>
        /// <param name="input">input string value. </param>
        /// <returns>a string value only contains numbers (from 0 to 9). </returns>
        public static string GetDigit(string input)
        {
            StringBuilder sb = new StringBuilder();
            if (!String.IsNullOrEmpty(input))
            {
                foreach (char c in input)
                {
                    if (char.IsDigit(c))
                    {
                        sb.Append(c);
                    }
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// GetDigitLetter removes characters that are not number or letter from the input string.
        /// </summary>
        /// <param name="input">input string value. </param>
        /// <returns>a string value only contains numbers or letters (from 0 to 9 or a(A) to z(Z)). </returns>
        public static string GetDigitLetter(string input)
        {
            StringBuilder sb = new StringBuilder();
            if (!String.IsNullOrEmpty(input))
            {
                foreach (char c in input)
                {
                    if (char.IsLetterOrDigit(c))
                    {
                        sb.Append(c);
                    }
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// GetString returns string coverted from input object value. it will return empty string when input is null.
        /// </summary>
        /// <param name="obj">an object value</param>
        /// <returns>a coverted string</returns>
        public static string SafeToString(object obj)
        {
            if (obj == null || obj == System.DBNull.Value)
            {
                return String.Empty;
            }
            else
            {
                try
                {
                    return System.Convert.ToString(obj, System.Globalization.CultureInfo.InvariantCulture);
                }
                catch 
                {
                    return String.Empty;
                }
            }
        }

        /// <summary>
        /// GetCurrentIdentityName retrieve the current threading identity name or windows identity name (when threading current pricipal is null).
        /// </summary>
        /// <returns>a string contains the crrent user identity name or empty string. </returns>
        public static string GetCurrentIdentityName()
        {
            string retVal = "";
            if (Thread.CurrentPrincipal != null && Thread.CurrentPrincipal.Identity != null)
            {
                retVal = Thread.CurrentPrincipal.Identity.Name;
            }
            if (String.IsNullOrEmpty(retVal))
            {
                WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();
                if (windowsIdentity != null)
                {
                    retVal = windowsIdentity.Name;
                }
            }
            return retVal;
        }

        /// <summary>
        /// Transform transforms xml with xslt to a file.
        /// </summary>
        /// <param name="xsltFile">xslt file path. </param>
        /// <param name="xmlFile">xml fuile path. </param>
        /// <param name="outputFile">output file path. </param>
        public static void Transform(string xsltFile, string xmlFile, string outputFile)
        {
            if (!String.IsNullOrEmpty(xsltFile) && !string.IsNullOrEmpty(xmlFile))
            {
                if (File.Exists(xsltFile) && File.Exists(xmlFile))
                {
                    XPathDocument xpathDoc = new XPathDocument(xmlFile);
                    XPathNavigator xpathNavigator = xpathDoc.CreateNavigator();

                    //Load xslt via XmlTextReader
                    XslCompiledTransform xslCompiledTransform = new XslCompiledTransform();
                    XmlUrlResolver xmlUrlResolver = new XmlUrlResolver();
                    xmlUrlResolver.Credentials = System.Net.CredentialCache.DefaultCredentials;
                    xslCompiledTransform.Load(xsltFile, XsltSettings.Default, xmlUrlResolver);

                    //transform the input to output
                    xslCompiledTransform.Transform(xmlFile, outputFile);
                }
            }
        }

        /// <summary>
        /// Transform transforms xml with xslt to a string.
        /// </summary>
        /// <param name="xsltFile">xslt file path. </param>
        /// <param name="xmlFile">xml fuile path. </param>
        /// <returns>a string conatins transformation result. </returns>
        public static string Transform(string xsltFile, string xmlFile)
        {
            string retVal = "";
            if (!String.IsNullOrEmpty(xsltFile) && !String.IsNullOrEmpty(xmlFile))
            {
                if (File.Exists(xsltFile) && File.Exists(xmlFile))
                {
                    using(StringWriter resultWriter = new StringWriter(System.Globalization.CultureInfo.CurrentUICulture))
                    {
                        XPathDocument xpathDoc = new System.Xml.XPath.XPathDocument(xmlFile);
                        XPathNavigator xpathNavigator = xpathDoc.CreateNavigator();

                        //Load xslt via XmlTextReader
                        XslCompiledTransform xslCompiledTransform = new XslCompiledTransform();
                        XmlUrlResolver xmlUrlResolver = new XmlUrlResolver();
                        xmlUrlResolver.Credentials = System.Net.CredentialCache.DefaultCredentials;
                        xslCompiledTransform.Load(xsltFile, XsltSettings.Default, xmlUrlResolver);

                        //transform the input to output
                        xslCompiledTransform.Transform(xmlFile, null, resultWriter);
                        retVal = resultWriter.ToString();
                        resultWriter.Close();
                    }
                }
            }
            return retVal;
        }

        /// <summary>
        /// ConvertToXsltOutputType converts a string array to XsltOutputType array.
        /// </summary>
        /// <param name="input">string array. </param>
        /// <returns>XsltOutputType array. </returns>
        public static XsltOutputType[] ConvertToXsltOutputType(string[] input)
        {
            XsltOutputType[] retVal = null;
            if (input != null && input.Length > 0)
            {
                retVal = new XsltOutputType[input.Length];
                for (int i = 0; i < input.Length; i++)
                {
                    if (input[i].Equals("1"))
                        retVal[i] = XsltOutputType.Combination;
                    else
                        retVal[i] = XsltOutputType.Individual;
                }
            }
            return retVal;
        }
    }
}
