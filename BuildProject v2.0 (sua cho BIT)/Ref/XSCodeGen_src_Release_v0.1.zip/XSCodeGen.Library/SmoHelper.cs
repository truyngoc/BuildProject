#region Copyright (C) 2006 Feng Liu
/*****************************************************************************
Copyright (C) 2006 Feng Liu

This class is used by XSCodeGen, a freeware initialized by Feng Liu. 
The intention of the XSCodeGen is to automatically generate classes and 
stored procedures basing on schema of tables in database by leveraging common
implementation pattern and practices.

Feel free to distribute and modify XSCodeGen to adopt your need. Please send feedback 
or your improvement back to Feng Liu, at waterman1997@hotmail.com. So other can benefit from 
these improvement and suggestions.

This XSCodeGen is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*****************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Diagnostics;

using Microsoft.SqlServer.Management;
using Microsoft.SqlServer.Management.Smo;

namespace XSCodeGen.Library
{
    /// <summary>
    /// SmoHelper is a helper class to populate SQL server objects via SMO library.
    /// </summary>
    public static class SmoHelper
    {
        /// <summary>
        /// XSCODEGEN_VERSION indicates the current version and date of XSCodeGen.
        /// </summary>
        internal const string XSCODEGEN_VERSION = "v0.6 2006-06-28";

        /// <summary>
        /// GetServers retrieves a list of SQL Servers in the local network.
        /// </summary>
        /// <returns></returns>
        public static DataTable GetServers()
        {
            //  Get a list of SQL servers available on the networks
            DataTable dtSQLServers = SmoApplication.EnumAvailableSqlServers(false);
            return dtSQLServers;
        }

        /// <summary>
        /// GetDatabases returnes a collection of database on the specified server.
        /// </summary>
        /// <param name="serverName"></param>
        /// <returns></returns>
        public static DatabaseCollection GetDatabases(string serverName)
        {
            Server selectedServer = new Server(serverName);
            return selectedServer.Databases;
        }

        /// <summary>
        /// GenerateEntityXmlFromTable generates a xml file basing on the information of the table passed in.
        /// </summary>
        /// <param name="table">an instance of SMO Table class. </param>
        /// <param name="keepSymbol">a boolean value indicates whether keep the symbol in table name and column names. </param>
        /// <param name="outputPath">the folder of the generated xml file. </param>
        /// <param name="spprefix">stored procedure prefix. </param>
        /// <param name="codeNamespace">namespace used by generated code. </param>
        public static void GenerateEntityXmlFromTable(Table table, bool keepSymbol, string outputPath, string spprefix, string codeNamespace)
        {
            GenerateEntityXmlFromTable(table, keepSymbol, outputPath, spprefix, codeNamespace, TableType.Normal);
        }

        /// <summary>
        /// GenerateEntityXmlFromTable generates a xml file basing on the information of the table passed in.
        /// </summary>
        /// <param name="table">an instance of SMO Table class. </param>
        /// <param name="keepSymbol">a boolean value indicates whether keep the symbol in table name and column names. </param>
        /// <param name="outputPath">the folder of the generated xml file. </param>
        /// <param name="spprefix">stored procedure prefix. </param>
        /// <param name="codeNamespace">namespace used by generated code. </param>
        /// <param name="tableType">Type of the table parameter, if it is lookup, entire table will be saved into output xml file. </param>
        public static void GenerateEntityXmlFromTable(Table table, bool keepSymbol, string outputPath, string spprefix, string codeNamespace, TableType tableType)
        {
            if (table != null && System.IO.Directory.Exists(outputPath))
            {
                Trace.WriteLine(String.Format("Process of table {0} starts at {1}.", table.Name, System.DateTime.Now.ToString("s")));

                string schema = table.Schema;

                string entityName, entityDesc;
                //remove symbols from name
                if (keepSymbol)
                    entityName = table.Name;
                else
                    entityName = Utility.GetDigitLetter(table.Name);

                entityDesc = String.Concat(schema, ".", table.Name);

                if(table.ExtendedProperties["MS_Description"]!=null)
                    entityDesc = String.Concat(entityDesc, " (", Utility.SafeToString(table.ExtendedProperties["MS_Description"].Value), ")");

                using (System.Xml.XmlTextWriter xtw = new System.Xml.XmlTextWriter(System.IO.Path.Combine(outputPath, String.Concat(entityName, ".xml")), System.Text.Encoding.UTF8))
                {
                    xtw.Formatting = System.Xml.Formatting.Indented;
                    xtw.WriteProcessingInstruction("xml", "version=\"1.0\" encoding=\"UTF-8\"");

                    //generate entity calss
                    xtw.WriteStartElement("entity");
                    xtw.WriteAttributeString("name", entityName);
                    xtw.WriteAttributeString("namespace", codeNamespace);
                    xtw.WriteAttributeString("author", Utility.GetCurrentIdentityName());
                    xtw.WriteAttributeString("createdDateTime", System.DateTime.Now.ToString("s"));
                    xtw.WriteAttributeString("schema", table.Schema);
                    xtw.WriteAttributeString("tableName", table.Name);
                    xtw.WriteAttributeString("description", entityDesc);
                    xtw.WriteAttributeString("spprefix", spprefix);
                    xtw.WriteAttributeString("XSCodeGen", XSCODEGEN_VERSION);

                    #region primary key
                    xtw.WriteStartElement("primaryKey");
                    foreach (Column col in table.Columns)
                    {
                        if (col.InPrimaryKey)
                        {
                            xtw.WriteStartElement("column");
                            xtw.WriteAttributeString("columnName", col.Name);
                            xtw.WriteEndElement();
                        }
                    }
                    xtw.WriteEndElement();
                    #endregion

                    #region ForeignKeys
                    xtw.WriteStartElement("foreignKeys");
                    foreach (ForeignKey fk in table.ForeignKeys)
                    {
                        xtw.WriteStartElement("foreignKey");
                        xtw.WriteAttributeString("name", fk.Name);
                        xtw.WriteAttributeString("referencedTableSchema", fk.ReferencedTableSchema);
                        xtw.WriteAttributeString("referencedTable", fk.ReferencedTable);
                        xtw.WriteAttributeString("referencedKey", fk.ReferencedKey);
                        foreach (ForeignKeyColumn fkCol in fk.Columns)
                        {
                            xtw.WriteStartElement("column");
                            xtw.WriteAttributeString("columnName", fkCol.Name);
                            xtw.WriteAttributeString("referencedColumn", fkCol.ReferencedColumn);
                            xtw.WriteEndElement();
                        }
                        xtw.WriteEndElement();
                    }
                    xtw.WriteEndElement();

                    #endregion

                    #region indexes
                    xtw.WriteStartElement("indexes");
                    foreach (Index idx in table.Indexes)
                    {
                        xtw.WriteStartElement("index");
                        xtw.WriteAttributeString("name", idx.Name);
                        xtw.WriteAttributeString("isClustered", idx.IsClustered.ToString(System.Globalization.CultureInfo.InvariantCulture));
                        xtw.WriteAttributeString("isUnique", idx.IsUnique.ToString(System.Globalization.CultureInfo.InvariantCulture));
                        xtw.WriteAttributeString("ignoreDuplicateKeys", idx.IgnoreDuplicateKeys.ToString(System.Globalization.CultureInfo.InvariantCulture));
                        foreach (IndexedColumn idxcol in idx.IndexedColumns)
                        {
                            xtw.WriteStartElement("column");
                            xtw.WriteAttributeString("columnName", idxcol.Name);
                            xtw.WriteAttributeString("descending", idxcol.Descending.ToString(System.Globalization.CultureInfo.InvariantCulture));
                            xtw.WriteAttributeString("isIncluded", idxcol.IsIncluded.ToString(System.Globalization.CultureInfo.InvariantCulture));
                            xtw.WriteEndElement();
                        }
                        xtw.WriteEndElement();
                    }
                    xtw.WriteEndElement();
                    #endregion

                    #region columns/properties
                    //generate property node
                    xtw.WriteStartElement("columns");
                    foreach (Column c in table.Columns)
                    {
                        GenerateXmlElementFromColumn(schema, table, c, keepSymbol, xtw, "property", false);
                    }
                    xtw.WriteEndElement();
                    #endregion

                    #region lookup values
                    if (tableType == TableType.Lookup)
                    {
                        string connStr = String.Concat("Integrated Security=SSPI;Data Source=", table.Parent.Parent.Name, ";Initial Catalog=", table.Parent.Name);
                        using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(connStr))
                        {
                            conn.Open();
                            string sqlText = "SELECT * FROM " + table.Schema + "." + table.Name + " FOR XML RAW, ELEMENTS XSINIL, ROOT('lookupValues')" ;
                            System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand(sqlText, conn);
                            comm.CommandText = sqlText;
                            comm.CommandType = CommandType.Text;
                            System.Xml.XmlReader xmlreader = comm.ExecuteXmlReader();
                            if (xmlreader != null)
                            {
                                System.Xml.XmlDocument xmldoc = new System.Xml.XmlDocument();
                                xmldoc.Load(xmlreader);
                                xtw.WriteRaw(String.Concat(Environment.NewLine, xmldoc.InnerXml, Environment.NewLine));
                            }
                            xmlreader.Close();
                            conn.Close();
                        }
                    }
                    #endregion

                    xtw.WriteEndElement();
                    xtw.Flush();
                    xtw.Close();
                }

                Trace.WriteLine(String.Format("Process of table {0} ends at {1}.", table.Name, System.DateTime.Now.ToString("s")));
            }
        }

        /// <summary>
        /// GenerateXmlElementFromColumn generate a xml element from column's definition.
        /// </summary>
        /// <param name="schema">schema name,</param>
        /// <param name="table">table name</param>
        /// <param name="c">column</param>
        /// <param name="keepSymbol">whether keep symbol when convert column anme to property name.</param>
        /// <param name="xtw">xml text writer</param>
        /// <param name="elementName">name of the xml element</param>
        /// <param name="sqlOnly">whether only generate the xml attributes that related to sql.</param>
        private static void GenerateXmlElementFromColumn(string schema, Table table, Column c, bool keepSymbol, System.Xml.XmlTextWriter xtw, string elementName, bool sqlOnly)
        {
            string fieldName, propertyName, type, initialValue, description, sqlType, sqlDefaultValue, sqlLength, sqlDesc;
            int uiLength = 0;
            bool identity = false, primaryKey = false, foreignKey = false, nullable = false;

            #region initialize common attributes
            if (keepSymbol)
                propertyName = c.Name;
            else
                propertyName = Utility.GetDigitLetter(c.Name);

            fieldName = string.Concat("m_", propertyName);
            initialValue = "";
            description = String.Concat("column of ", String.Concat(schema, ".", table.Name, "."), c.Name);
            sqlLength = c.DataType.MaximumLength.ToString(System.Globalization.CultureInfo.InvariantCulture);
            nullable = c.Nullable;

            if (c.ExtendedProperties["MS_Description"] != null)
                sqlDesc = Utility.SafeToString(c.ExtendedProperties["MS_Description"].Value);
            else
                sqlDesc = c.Name.Replace('_', ' ');

            description = String.Concat(description, " (", sqlDesc, ")");

            identity = c.Identity;
            primaryKey = c.InPrimaryKey;
            foreignKey = c.IsForeignKey;
            sqlType = c.DataType.SqlDataType.ToString();
            #endregion

            #region initial type depended attributes
            switch (c.DataType.SqlDataType)
            {
                case SqlDataType.BigInt:
                    type = "long";
                    initialValue = "0";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(long.MaxValue).Length + 1;
                    break;

                case SqlDataType.Int:
                    type = "int";
                    initialValue = "0";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(int.MaxValue).Length + 1;
                    break;

                case SqlDataType.SmallInt:
                    type = "short";
                    initialValue = "0";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(short.MaxValue).Length + 1;
                    break;

                case SqlDataType.TinyInt:
                    type = "byte";
                    initialValue = "0";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(byte.MaxValue).Length;
                    break;

                case SqlDataType.Bit:
                    type = "bool";
                    initialValue = "false";
                    sqlDefaultValue = "0";
                    uiLength = 5;
                    break;

                case SqlDataType.Decimal:
                case SqlDataType.Numeric:
                    type = "decimal";
                    initialValue = "0M";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(decimal.MaxValue).Length + 1;
                    sqlType += "(" + c.DataType.NumericPrecision.ToString() + ", " + c.DataType.NumericScale.ToString() + ")";
                    break;

                case SqlDataType.Money:
                case SqlDataType.SmallMoney:
                    type = "decimal";
                    initialValue = "0M";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(decimal.MaxValue).Length + 1;
                    break;

                case SqlDataType.Float:
                    type = "double";
                    initialValue = "0D";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(double.MaxValue).Length + 1;
                    break;

                case SqlDataType.Real:
                    type = "float";
                    initialValue = "0F";
                    sqlDefaultValue = "0";
                    uiLength = Utility.SafeToString(double.MaxValue).Length + 1;
                    break;

                case SqlDataType.DateTime:
                case SqlDataType.SmallDateTime:
                    type = "System.DateTime";
                    initialValue = "System.DateTime.MinValue";
                    sqlDefaultValue = "null";
                    uiLength = 10;
                    break;

                case SqlDataType.UniqueIdentifier:
                    type = "System.Guid";
                    initialValue = "System.Guid.Empty";
                    sqlDefaultValue = "null";
                    uiLength = 32;
                    break;

                case SqlDataType.Char:
                case SqlDataType.NChar:
                case SqlDataType.VarChar:
                case SqlDataType.VarCharMax:
                case SqlDataType.NVarChar:
                case SqlDataType.NVarCharMax:
                case SqlDataType.Text:
                case SqlDataType.NText:
                    type = "string";
                    initialValue = "\"\"";
                    sqlDefaultValue = "''''";
                    uiLength = c.DataType.MaximumLength;
                    if (uiLength <= 0) uiLength = 0;
                    if (c.DataType.SqlDataType != SqlDataType.Text
                        && c.DataType.SqlDataType != SqlDataType.NText)
                    {
                        if (c.DataType.MaximumLength > 0)
                            sqlType += "(" + c.DataType.MaximumLength.ToString() + ")";
                        else
                        {
                            sqlType = sqlType.Remove(sqlType.Length - 3) + "(max)";
                        }
                    }
                    break;

                //following SqlDataType are not processed in this version
                case SqlDataType.Binary:
                case SqlDataType.Image:
                case SqlDataType.SysName:
                case SqlDataType.Timestamp:
                case SqlDataType.VarBinary:
                case SqlDataType.VarBinaryMax:
                case SqlDataType.Variant:
                case SqlDataType.Xml:
                case SqlDataType.UserDefinedType:
                case SqlDataType.UserDefinedDataType:
                    type = "string";
                    initialValue = "\"\"";
                    sqlDefaultValue = "''''";
                    break;

                default:
                    type = "string";
                    initialValue = "\"\"";
                    sqlDefaultValue = "''''";
                    break;
            }

            #endregion

            #region process nullable
            if (c.Nullable)
            {
                if (!type.Equals("string", StringComparison.InvariantCultureIgnoreCase))
                {
                    type = string.Concat(type, "?");
                }
                initialValue = "null";
                sqlDefaultValue = "null";
            }
            #endregion

            #region write xml element
            xtw.WriteStartElement(elementName);
            if (sqlOnly)
            {
                xtw.WriteAttributeString("columnName", c.Name);
                xtw.WriteAttributeString("sqlType", sqlType);
                xtw.WriteAttributeString("sqlLength", sqlLength);
                xtw.WriteAttributeString("sqlDefaultValue", sqlDefaultValue);
                xtw.WriteAttributeString("identity", identity.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("primaryKey", primaryKey.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("foreignKey", foreignKey.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("nullable", nullable.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("sqlDescription", sqlDesc);
            }
            else
            {
                xtw.WriteAttributeString("name", propertyName);
                xtw.WriteAttributeString("field", fieldName);
                xtw.WriteAttributeString("type", type);
                xtw.WriteAttributeString("initialValue", initialValue);
                xtw.WriteAttributeString("columnName", c.Name);
                xtw.WriteAttributeString("sqlType", sqlType);
                xtw.WriteAttributeString("sqlLength", sqlLength);
                xtw.WriteAttributeString("sqlDefaultValue", sqlDefaultValue);
                xtw.WriteAttributeString("identity", identity.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("primaryKey", primaryKey.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("foreignKey", foreignKey.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("nullable", nullable.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("uiLength", uiLength.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xtw.WriteAttributeString("description", description);
                xtw.WriteAttributeString("sqlDescription", sqlDesc);
            }
            xtw.WriteEndElement();
            #endregion
        }

    }
}
