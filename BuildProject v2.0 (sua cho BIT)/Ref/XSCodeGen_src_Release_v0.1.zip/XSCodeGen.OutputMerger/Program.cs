using System;
using System.Collections.Generic;
using System.Text;

namespace XSCodeGen.OutputMerger
{
    class Program
    {
        /// <summary>
        /// Mains the specified args.
        /// </summary>
        /// <param name="args">The args.</param>
        static void Main(string[] args)
        {
            if (args != null && args.Length > 2)
            {
                string outputFilePath = null, xmlFolder = null, xsltFolder = null, containerFilePath = null, placeholder = null;

                foreach (string s in args)
                {
                    if (s.StartsWith("/xml:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        xmlFolder = s.Remove(0, 5).Trim();
                    }
                    else if (s.StartsWith("/xslt:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        xsltFolder = s.Remove(0, 6).Trim();
                    }
                    else if (s.StartsWith("/o:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        outputFilePath = s.Remove(0, 3).Trim();
                    }
                    else if (s.StartsWith("/t:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        containerFilePath = s.Remove(0, 3).Trim();
                    }
                    else if (s.StartsWith("/ph:", StringComparison.InvariantCultureIgnoreCase))
                    {
                        placeholder = s.Remove(0, 4).Trim();
                    }
                }

                if (!String.IsNullOrEmpty(xmlFolder)
                    && !String.IsNullOrEmpty(xsltFolder)
                    && !String.IsNullOrEmpty(outputFilePath))
                {

                    XSCodeGen.Library.CodeGenerator.GenerateFile(xmlFolder, xsltFolder, outputFilePath, containerFilePath, placeholder);
                }
            }
        }

    }
}
